<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Care Indonesia</title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('style/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('style/css/sb-admin-2.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('style/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

    


    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


    
    <link rel="stylesheet" href="<?php echo e(asset('css_2/style.css')); ?>">

</head>
<body>


    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('style/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('style/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('style/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('style/js/sb-admin-2.min.js')); ?>"></script>

    

    <!-- Page level plugins -->
    

    <!-- Page level custom scripts -->
    

    
    <script src="<?php echo e(asset('js_2/script.js')); ?>"></script>

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Careind\careind\resources\views/layouts/template.blade.php ENDPATH**/ ?>