 <!-- Custom scripts for all pages-->
 <script src="<?php echo e(asset('style/js/sb-admin-2.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\Careind\careind\resources\views/layouts/script.blade.php ENDPATH**/ ?>